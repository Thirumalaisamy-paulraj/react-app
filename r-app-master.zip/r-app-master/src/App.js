import React from 'react';
import './App.css';
import Products from './components/Products'
function App() {
  return (
    <div className="App">
      <Products />
    </div>
  );
}

export default App;
